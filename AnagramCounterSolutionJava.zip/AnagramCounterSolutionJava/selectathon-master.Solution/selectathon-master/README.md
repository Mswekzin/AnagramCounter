# selectathon
Java and .Net anagram exercise for recruitment
