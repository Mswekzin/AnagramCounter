import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class AnagramService {

    public List<AnagramCounter> compute(String dictionaryLocation) throws IOException {
		@SuppressWarnings("unchecked")
		List<String> words = FileUtils.readLines(new File(dictionaryLocation));        

        // Inner hashmap counts frequency of characters in a string. 
        // Outer hashmap for if same 
        // frequency characters are present in 
        // in a string then it will add it to 
        // the arraylist. 
        HashMap<HashMap<Character, Integer>,ArrayList<String> > map;
        map = new HashMap<HashMap<Character, Integer>, ArrayList<String> >();
        
        for (String word : words) {
        	HashMap<Character, Integer> tempMap = new HashMap<Character, Integer>();
        	
        	// Counting the frequency of the 
            // characters present in a word 
            for (int i = 0; i < word.length(); i++) { 
                if (tempMap.containsKey(word.charAt(i))) { 
                    int x = tempMap.get(word.charAt(i)); 
                    tempMap.put(word.charAt(i), ++x); 
                } 
                else { 
                    tempMap.put(word.charAt(i), 1); 
                } 
            } 
            
            // If the same frequency of characters 
            // are already present then add that 
            // string into that arraylist otherwise 
            // created a new arraylist and add that string 
            
            if (map.containsKey(tempMap)) 
                map.get(tempMap).add(word); 
            else { 
                ArrayList<String> tempList = new ArrayList<String>(); 
                tempList.add(word); 
                map.put(tempMap, tempList); 
            } 
            //System.out.println("TODO process word: " + word);
        }
        
        ArrayList<AnagramCounter> result = getOutputResults(map);
       
        // TODO: This is just a placeholder - you should change this
        return result;
    }
    
    
    public ArrayList<AnagramCounter> getOutputResults(HashMap<HashMap<Character, Integer>,ArrayList<String> > map){
    	HashMap<Integer, Integer> resultsMap = new HashMap<>();
        
    	for (HashMap.Entry<HashMap<Character, Integer>, ArrayList<String>> entry : map.entrySet()) {
     	   ArrayList<String> temp = entry.getValue();
     	   if(temp.size() < 2) continue;
     	   
     	   int wordLength = temp.get(0).length();
     	   if(resultsMap.containsKey(wordLength)) {
     		   resultsMap.put(wordLength, resultsMap.get(wordLength) +1);
     	   }
     	   else {
     		  resultsMap.put(wordLength, 1); 
     	   }
        }
    	
    	ArrayList<AnagramCounter> results = new ArrayList<>();
    	
    	for(HashMap.Entry<Integer, Integer> entry: resultsMap.entrySet()) {
    		results.add(new AnagramCounter(entry.getKey(), entry.getValue()));
    	}
    	
    	return results;
    }
}

